using System.Text.Json;
using GoldSrcProbe.Config;
using GoldSrcProbe.Models;
using GoldSrcProbe.Protocol;

namespace GoldSrcProbe.Services;

public sealed class ProbeRunner(AppConfig config)
{
    public async Task<ProbeReport> RunAsync(IEnumerable<ServerEndpoint> servers, CancellationToken ct = default)
    {
        var mode = config.Mode.ToLowerInvariant();
        var doA2S = mode is "a2s" or "both";
        var doConnect = mode is "connect" or "both";

        var report = new ProbeReport();
        var list = servers.ToList();

        Console.WriteLine($"=== GoldSrc Probe ===");
        Console.WriteLine($"Servers: {list.Count} | Mode: {config.Mode}");
        Console.WriteLine();

        foreach (var server in list)
        {
            ct.ThrowIfCancellationRequested();
            var result = new ServerProbeResult { Address = server.Key };
            Console.Write($"[{server.Key}] ");

            if (doA2S)
            {
                using var a2s = new A2SClient(config.A2STimeoutMs);
                var (info, players, err) = await a2s.QueryAsync(server, ct);
                if (info is not null)
                {
                    result.Online = true;
                    result.A2S = info;
                    result.A2SPlayers = players;
                    Console.Write($"A2S:{info.Players}/{info.MaxPlayers}");
                    if (players.Count > 0 && players.Count < info.Players)
                        Console.Write($" list:{players.Count}");
                    if (info.LikelyReHlds)
                        Console.Write($" ReHLDS:{info.ReHldsVersion}");
                    Console.Write(' ');
                }
                else
                {
                    result.Online = false;
                    result.Error = err;
                    Console.Write($"A2S:OFF ");
                }
            }

            if (doConnect)
            {
                using var client = new GoldSrcClient(config.PlayerName, config.ConnectTimeoutMs, config);
                var reach = await client.ProbeConnectAsync(server, ct);
                result.ConnectReachability = reach.Reachability switch
                {
                    ConnectReachability.Open => "open",
                    ConnectReachability.A2SShield => "a2s-shield",
                    _ => "no-response"
                };

                if (!reach.CanJoin)
                {
                    result.ConnectOk = false;
                    result.ConnectError = reach.Summary;
                    var tag = reach.Reachability switch
                    {
                        ConnectReachability.A2SShield => "shield",
                        ConnectReachability.NoResponse => "no-response",
                        _ => "skip"
                    };
                    Console.Write($"CONNECT:skip({tag}) ");
                }
                else
                {
                    var (ok, statusPlayers, connectErr, _) = await client.ProbeStatusAsync(server, ct);
                    result.ConnectOk = ok;
                    result.StatusPlayers = statusPlayers;
                    result.ConnectError = connectErr;
                    result.SignonState = client.ConnectionState;
                    Console.Write($"CONNECT:{(ok ? statusPlayers.Count : 0)} signon:{client.ConnectionState}");
                    if (result.FakePlayerSuspect == true)
                        Console.Write(" SUSPECT");
                    if (!ok && connectErr is not null)
                        Console.Write($" ({connectErr}) ");
                    else
                        Console.Write(' ');
                }
            }

            report.Servers.Add(result);
            Console.WriteLine();

            if (config.DelayBetweenServersMs > 0)
                await Task.Delay(config.DelayBetweenServersMs, ct);
        }

        return report;
    }

    public async Task SaveReportAsync(ProbeReport report, CancellationToken ct = default)
    {
        var path = config.OutputFile;
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);

        var json = JsonSerializer.Serialize(report, AppConfig.JsonOptions());
        await File.WriteAllTextAsync(path, json, ct);
        Console.WriteLine($"Saved: {Path.GetFullPath(path)}");
    }

    public static List<ServerEndpoint> LoadServers(string path)
    {
        if (!File.Exists(path))
            throw new FileNotFoundException($"Servers file not found: {path}");

        var servers = new List<ServerEndpoint>();
        foreach (var line in File.ReadAllLines(path))
        {
            if (string.IsNullOrWhiteSpace(line) || line.TrimStart().StartsWith('#'))
                continue;
            servers.Add(ServerEndpoint.Parse(line));
        }

        return servers;
    }
}
