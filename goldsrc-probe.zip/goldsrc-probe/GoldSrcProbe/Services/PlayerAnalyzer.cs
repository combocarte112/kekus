using GoldSrcProbe.Models;

namespace GoldSrcProbe.Services;

public static class PlayerAnalyzer
{
    public static VerifySummary Analyze(IReadOnlyList<StatusPlayer> players, string? knownProbeName = null)
    {
        var analyzed = new List<AnalyzedPlayer>(players.Count);
        var steamCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        foreach (var p in players)
        {
            p.AuthKind = ReUnionAuthClassifier.Classify(p.UniqueId, knownProbeName, p.Name);

            if (!string.IsNullOrEmpty(p.UniqueId))
                steamCounts[p.UniqueId] = steamCounts.GetValueOrDefault(p.UniqueId) + 1;
        }

        var humanLike = players.Where(p => p.AuthKind is not SteamAuthKind.EngineBot and not SteamAuthKind.ProbeBot).ToList();
        var pings = humanLike.Where(p => p.Ping > 0).Select(p => p.Ping).ToList();
        var allSamePing = pings.Count >= 2 && pings.Distinct().Count() == 1;

        foreach (var p in players)
        {
            var reasons = new List<string>();
            var trust = ClassifyTrust(p, steamCounts, allSamePing, humanLike.Count, reasons);

            analyzed.Add(new AnalyzedPlayer
            {
                UserId = p.UserId,
                Name = p.Name,
                SteamId = p.UniqueId,
                Ping = p.Ping,
                Time = p.Time,
                Frags = p.Frags,
                Loss = p.Loss,
                Address = p.Address,
                Trust = trust,
                AuthKind = p.AuthKind,
                Reasons = reasons
            });
        }

        var countable = analyzed.Where(p => p.Trust is not PlayerTrust.Probe).ToList();

        return new VerifySummary
        {
            Total = analyzed.Count,
            Real = analyzed.Count(x => x.Trust == PlayerTrust.Real),
            Bots = analyzed.Count(x => x.Trust == PlayerTrust.Bot),
            Emulators = analyzed.Count(x => x.Trust == PlayerTrust.Emulator),
            Probes = analyzed.Count(x => x.Trust == PlayerTrust.Probe),
            Suspicious = analyzed.Count(x => x.Trust == PlayerTrust.Suspicious),
            Players = analyzed,
            LikelyFakeServer = countable.Count >= 3 &&
                               analyzed.Count(x => x.Trust == PlayerTrust.Emulator) +
                               analyzed.Count(x => x.Trust == PlayerTrust.Suspicious) >=
                               Math.Max(2, (int)Math.Ceiling(countable.Count * 0.5))
        };
    }

    private static PlayerTrust ClassifyTrust(
        StatusPlayer p,
        Dictionary<string, int> steamCounts,
        bool allSamePing,
        int humanLikeCount,
        List<string> reasons)
    {
        switch (p.AuthKind)
        {
            case SteamAuthKind.ProbeBot:
                reasons.Add("probe_bot");
                return PlayerTrust.Probe;
            case SteamAuthKind.EngineBot:
                reasons.Add("uniqueid=BOT");
                return PlayerTrust.Bot;
            case SteamAuthKind.LegitSteam:
                break;
            case SteamAuthKind.Emulator:
                reasons.Add("reunion_emulator");
                return PlayerTrust.Emulator;
            case SteamAuthKind.Valve:
            case SteamAuthKind.Lan:
            case SteamAuthKind.Pending:
            case SteamAuthKind.Hltv:
                reasons.Add($"auth={ReUnionAuthClassifier.Describe(p.AuthKind)}");
                return PlayerTrust.Suspicious;
            default:
                if (!StatusParser.IsValidSteamIdFormat(p.UniqueId))
                {
                    reasons.Add("invalid_steamid_format");
                    return PlayerTrust.Suspicious;
                }
                break;
        }

        if (p.UniqueId.Equals("STEAM_0:0:0", StringComparison.OrdinalIgnoreCase) ||
            p.UniqueId.Equals("STEAM_1:0:0", StringComparison.OrdinalIgnoreCase))
        {
            reasons.Add("zero_steamid");
            return PlayerTrust.Suspicious;
        }

        if (steamCounts.GetValueOrDefault(p.UniqueId) > 1)
        {
            reasons.Add("duplicate_steamid");
            return PlayerTrust.Suspicious;
        }

        if (p.Ping <= 0 && p.Frags == 0 && p.Time is "00:00" or "0:00" or "00:00:00")
        {
            reasons.Add("zero_ping_time_frags");
            return PlayerTrust.Suspicious;
        }

        if (allSamePing && p.Ping > 0 && humanLikeCount >= 3)
        {
            reasons.Add("identical_ping_all");
            return PlayerTrust.Suspicious;
        }

        if (p.Address is "127.0.0.1:0" or "0.0.0.0:0" && humanLikeCount >= 2)
        {
            reasons.Add("missing_or_fake_adr");
            return PlayerTrust.Suspicious;
        }

        return p.AuthKind == SteamAuthKind.LegitSteam ? PlayerTrust.Real : PlayerTrust.Emulator;
    }
}
