using System.Text.RegularExpressions;
using GoldSrcProbe.Models;

namespace GoldSrcProbe.Services;

/// <summary>
/// ReUnion AuthVersion >= 2018: STEAM_a:b:c first segment (a) = auth_key_kind (0 = real Steam).
/// Legacy ReUnion: first segment = emulator type prefix from reunion.cfg.
/// </summary>
public static partial class ReUnionAuthClassifier
{
    [GeneratedRegex(@"^STEAM_(\d+):([01]):(\d+)$", RegexOptions.Compiled | RegexOptions.IgnoreCase)]
    private static partial Regex SteamPartsRegex();

    public static SteamAuthKind Classify(string uniqueId, string? knownProbeName = null, string? playerName = null)
    {
        if (string.IsNullOrWhiteSpace(uniqueId))
            return SteamAuthKind.Unknown;

        if (uniqueId.Equals("BOT", StringComparison.OrdinalIgnoreCase))
            return SteamAuthKind.EngineBot;

        if (uniqueId.Equals("HLTV", StringComparison.OrdinalIgnoreCase))
            return SteamAuthKind.Hltv;

        if (uniqueId.Equals("STEAM_ID_LAN", StringComparison.OrdinalIgnoreCase))
            return SteamAuthKind.Lan;

        if (uniqueId.Equals("STEAM_ID_PENDING", StringComparison.OrdinalIgnoreCase))
            return SteamAuthKind.Pending;

        if (uniqueId.StartsWith("VALVE_", StringComparison.OrdinalIgnoreCase))
            return SteamAuthKind.Valve;

        if (!SteamPartsRegex().IsMatch(uniqueId))
            return SteamAuthKind.Unknown;

        if (IsKnownProbe(knownProbeName, playerName))
            return SteamAuthKind.ProbeBot;

        var prefix = int.Parse(SteamPartsRegex().Match(uniqueId).Groups[1].Value);

        // ReUnion 2018+ auth_key_kind: 0 = AK_STEAM (legit Steam client)
        if (prefix == 0)
            return SteamAuthKind.LegitSteam;

        // 1-5 = HW/file/volume auth keys used by emulators; 6 = AK_MAX (often IP-gen display)
        return SteamAuthKind.Emulator;
    }

    public static string Describe(SteamAuthKind kind) => kind switch
    {
        SteamAuthKind.LegitSteam => "steam",
        SteamAuthKind.Emulator => "emulator",
        SteamAuthKind.ProbeBot => "probe",
        SteamAuthKind.EngineBot => "bot",
        SteamAuthKind.Valve => "valve",
        SteamAuthKind.Lan => "lan",
        SteamAuthKind.Pending => "pending",
        SteamAuthKind.Hltv => "hltv",
        _ => "unknown"
    };

    public static bool IsKnownProbe(string? knownProbeName, string? playerName)
    {
        if (string.IsNullOrWhiteSpace(knownProbeName) || string.IsNullOrWhiteSpace(playerName))
            return false;

        return playerName.Equals(knownProbeName, StringComparison.OrdinalIgnoreCase);
    }
}
