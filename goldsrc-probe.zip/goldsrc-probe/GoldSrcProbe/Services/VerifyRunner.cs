using System.Text.Json;
using GoldSrcProbe.Config;
using GoldSrcProbe.Models;
using GoldSrcProbe.Protocol;

namespace GoldSrcProbe.Services;

public sealed class VerifyRunner(AppConfig config)
{
    public async Task<VerifyReport> RunAsync(IEnumerable<ServerEndpoint> servers, CancellationToken ct = default)
    {
        var report = new VerifyReport();
        var list = servers.ToList();

        Console.WriteLine("=== GoldSrc Verify (join + status) ===");
        Console.WriteLine($"Servers: {list.Count} | Bot: {config.PlayerName}");
        Console.WriteLine();

        foreach (var server in list)
        {
            ct.ThrowIfCancellationRequested();
            Console.WriteLine($"[{server.Key}]");

            ServerVerifyResult result = new() { Address = server.Key };
            for (var attempt = 1; attempt <= 3; attempt++)
            {
                if (attempt > 1)
                {
                    Console.WriteLine($"  retry {attempt}/3 — overflow, port UDP +{(attempt - 1) * 3}...");
                    await Task.Delay(6000, ct);
                }

                var bindPort = config.BindPort <= 0
                    ? 0
                    : config.BindPort + (attempt - 1) * 3;
                using var client = new GoldSrcClient(
                    config.PlayerName, config.ConnectTimeoutMs, config, bindPort);
                result = await client.VerifyPlayersAsync(server, ct);
                if (result.Joined)
                    break;

                if (result.Error is null)
                    break;

                var retryable = result.Error.Contains("overflow", StringComparison.OrdinalIgnoreCase) ||
                                  result.Error.Contains("Signon stuck", StringComparison.OrdinalIgnoreCase) ||
                                  result.Error.Contains("Bad file", StringComparison.OrdinalIgnoreCase);
                if (!retryable)
                    break;
            }
            if (result.Reachability is null)
            {
                result.Reachability = result.Joined
                    ? "open"
                    : ConnectReject.ReachabilityFor(result.Error);
            }

            report.Servers.Add(result);
            PrintResult(result);
            Console.WriteLine();

            if (config.DelayBetweenServersMs > 0)
                await Task.Delay(config.DelayBetweenServersMs, ct);
        }

        return report;
    }

    private static void PrintResult(ServerVerifyResult r)
    {
        if (r.Reachability is "a2s-shield" or "no-response")
        {
            Console.WriteLine($"  SKIP — {r.Error ?? r.Reachability}");
            return;
        }

        if (r.Reachability == "full")
        {
            var tries = r.ConnectAttempts > 0 ? $" ({r.ConnectAttempts} attempt(s))" : "";
            Console.WriteLine($"  FULL — {r.Error}{tries}");
            return;
        }

        if (!r.Joined)
        {
            var auth = r.AuthUsed is not null ? $" auth:{r.AuthUsed}" : "";
            Console.WriteLine($"  FAIL — {r.Error}{auth}");
            return;
        }

        var s = r.Summary;
        if (s is null)
        {
            Console.WriteLine($"  JOIN OK signon:{r.SignonState}");
            return;
        }

        var flag = s.LikelyFakeServer ? " *** LIKELY FAKE ***" : "";
        Console.WriteLine(
            $"  JOIN OK | auth:{r.AuthUsed ?? "?"} | players:{s.Total} steam:{s.Real} emu:{s.Emulators} probe:{s.Probes} bot:{s.Bots} suspicious:{s.Suspicious}{flag}");

        if (s.Total == 0)
        {
            Console.WriteLine("  (server gol — 0 jucatori)");
            if (r.Error is not null)
                Console.WriteLine($"  Note: {r.Error}");
            return;
        }

        foreach (var p in s.Players)
        {
            var tag = p.Trust switch
            {
                PlayerTrust.Real => "STM",
                PlayerTrust.Emulator => "EMU",
                PlayerTrust.Probe => "PRB",
                PlayerTrust.Bot => "BOT",
                PlayerTrust.Suspicious => "FAK",
                _ => "???"
            };
            var auth = ReUnionAuthClassifier.Describe(p.AuthKind);
            var why = p.Reasons.Count > 0 ? $" [{string.Join(", ", p.Reasons)}]" : "";
            Console.WriteLine(
                $"    [{tag}] #{p.UserId,-2} {p.Name,-20} {p.SteamId,-22} auth:{auth,-8} ping:{p.Ping,4} time:{p.Time,8}{why}");
        }
    }

    public async Task SaveReportAsync(VerifyReport report, CancellationToken ct = default)
    {
        var path = string.IsNullOrWhiteSpace(config.VerifyOutputFile)
            ? "output/verify_players.json"
            : config.VerifyOutputFile;
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);

        var json = JsonSerializer.Serialize(report, AppConfig.JsonOptions());
        await File.WriteAllTextAsync(path, json, ct);
        Console.WriteLine($"Saved: {Path.GetFullPath(path)}");
    }
}
