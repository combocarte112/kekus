using System.Text.RegularExpressions;
using GoldSrcProbe.Models;

namespace GoldSrcProbe.Services;

public static partial class StatusParser
{
    // ReHLDS Host_Status_f: # slot "name" engine_userid uniqueid frag time ping loss adr
    [GeneratedRegex(@"^#\s*(\d+)\s+""([^""]*)""\s+(\d+)\s+(\S+)(.*)$", RegexOptions.Compiled)]
    private static partial Regex PlayerLineReHldsRegex();

    // Legacy HL: # slot "name" uniqueid frag time ping loss adr
    [GeneratedRegex(@"^#\s*(\d+)\s+""([^""]*)""\s+(\S+)(.*)$", RegexOptions.Compiled)]
    private static partial Regex PlayerLineLegacyRegex();

    [GeneratedRegex(@"^STEAM_\d+:[01]:\d+$", RegexOptions.Compiled | RegexOptions.IgnoreCase)]
    private static partial Regex SteamIdRegex();

    [GeneratedRegex(@"^\d{15,20}$", RegexOptions.Compiled)]
    private static partial Regex SteamId64Regex();

    public static List<StatusPlayer> Parse(string raw)
    {
        var players = new List<StatusPlayer>();
        if (string.IsNullOrWhiteSpace(raw))
            return players;

        var preferReHlds = IsReHldsStatusFormat(raw);

        foreach (var line in raw.Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            var trimmed = line.Trim('\r', ' ', '\t');
            if (trimmed.Length == 0 || trimmed.StartsWith('#') && LooksLikeStatusHeader(trimmed))
                continue;

            var player = TryParseLine(trimmed, preferReHlds);
            if (player is not null)
                players.Add(player);
        }

        return players;
    }

    private static StatusPlayer? TryParseLine(string trimmed, bool preferReHlds)
    {
        if (preferReHlds)
        {
            var reHlds = TryParseReHlds(trimmed);
            if (reHlds is not null && IsPlausibleUniqueId(reHlds.UniqueId))
                return reHlds;
        }

        var legacy = TryParseLegacy(trimmed);
        if (legacy is not null && IsPlausibleUniqueId(legacy.UniqueId))
            return legacy;

        if (preferReHlds)
            return TryParseReHlds(trimmed) ?? legacy;

        return legacy ?? TryParseReHlds(trimmed);
    }

    private static StatusPlayer? TryParseReHlds(string trimmed)
    {
        var m = PlayerLineReHldsRegex().Match(trimmed);
        if (!m.Success)
            return null;

        var uid = m.Groups[4].Value;
        if (uid.Contains("HLTV", StringComparison.OrdinalIgnoreCase))
            return null;

        return BuildPlayer(m.Groups[1].Value, m.Groups[2].Value, uid, m.Groups[5].Value);
    }

    private static StatusPlayer? TryParseLegacy(string trimmed)
    {
        var m = PlayerLineLegacyRegex().Match(trimmed);
        if (!m.Success)
            return null;

        var uid = m.Groups[3].Value;
        if (uid.Contains("HLTV", StringComparison.OrdinalIgnoreCase))
            return null;

        // ReHLDS line misparsed as legacy when 3rd token is engine userid (digits only).
        if (IsBareNumericId(uid))
            return null;

        return BuildPlayer(m.Groups[1].Value, m.Groups[2].Value, uid, m.Groups[4].Value);
    }

    private static StatusPlayer BuildPlayer(string slot, string name, string uniqueId, string rest)
    {
        var player = new StatusPlayer
        {
            UserId = slot,
            Name = name,
            UniqueId = uniqueId
        };

        var fields = rest.Trim().Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        var idx = 0;

        // Skip optional HLTV block: hltv:specs/slots delay:ms
        if (fields.Length > idx && fields[idx].StartsWith("hltv:", StringComparison.OrdinalIgnoreCase))
        {
            idx++;
            if (fields.Length > idx && fields[idx].StartsWith("delay:", StringComparison.OrdinalIgnoreCase))
                idx++;
        }

        if (fields.Length > idx && int.TryParse(fields[idx], out var frags))
        {
            player.Frags = frags;
            idx++;
        }

        if (fields.Length > idx && LooksLikeTime(fields[idx]))
        {
            player.Time = fields[idx];
            idx++;
        }

        if (fields.Length > idx && int.TryParse(fields[idx], out var ping))
        {
            player.Ping = ping;
            idx++;
        }

        if (fields.Length > idx && int.TryParse(fields[idx], out var loss))
        {
            player.Loss = loss;
            idx++;
        }

        if (fields.Length > idx)
            player.Address = fields[idx];

        return player;
    }

    private static bool LooksLikeTime(string token) => token.Contains(':');

    private static bool IsBareNumericId(string token) =>
        token.Length > 0 && token.All(char.IsDigit) && token.Length < 15;

    private static bool IsPlausibleUniqueId(string uniqueId) =>
        !IsBareNumericId(uniqueId) && IsValidSteamIdFormat(uniqueId);

    public static bool IsReHldsStatusFormat(string raw) =>
        raw.Contains("# name userid uniqueid", StringComparison.OrdinalIgnoreCase);

    public static bool LooksLikeStatusHeader(string text) =>
        text.Contains("# name", StringComparison.OrdinalIgnoreCase) ||
        text.Contains("# userid", StringComparison.OrdinalIgnoreCase) ||
        text.Contains("uniqueid", StringComparison.OrdinalIgnoreCase);

    public static bool IsValidSteamIdFormat(string uniqueId)
    {
        if (string.IsNullOrWhiteSpace(uniqueId))
            return false;

        if (uniqueId.Equals("BOT", StringComparison.OrdinalIgnoreCase))
            return true;

        if (uniqueId.Equals("LAN", StringComparison.OrdinalIgnoreCase) ||
            uniqueId.Equals("STEAM_ID_LAN", StringComparison.OrdinalIgnoreCase) ||
            uniqueId.Equals("STEAM_ID_PENDING", StringComparison.OrdinalIgnoreCase))
            return true;

        if (uniqueId.StartsWith("VALVE_", StringComparison.OrdinalIgnoreCase))
            return true;

        if (SteamIdRegex().IsMatch(uniqueId))
            return true;

        return SteamId64Regex().IsMatch(uniqueId);
    }
}
