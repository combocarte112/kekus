namespace GoldSrcProbe.Protocol;

internal sealed class ServerResource
{
    public string Name = string.Empty;
    public byte ResourceType;
    public uint ResourceIndex;
    public uint DownloadSize;
    public byte Flags;
    public byte[] Md5 = new byte[16];
    public byte[] Reserved = new byte[32];
    public bool NeedConsistency;
}
