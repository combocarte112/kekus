using System.Numerics;
using System.Runtime.InteropServices;

namespace GoldSrcProbe.Protocol;

/// <summary>
/// Delta-encodes usercmd_t per valve/delta.lst (CS 1.6 build 4554).
/// </summary>
internal static class UsercmdDeltaWriter
{
    private const int FieldCount = 15;

    private enum FieldType : byte
    {
        Short,
        Byte,
        Angle,
        SignedFloat12,
        Integer6,
        SignedFloat16x8
    }

    private readonly struct FieldDef(int wireIndex, int offset, FieldType type, int bits, float premultiply = 1f)
    {
        public readonly int WireIndex = wireIndex;
        public readonly int Offset = offset;
        public readonly FieldType Type = type;
        public readonly int Bits = bits;
        public readonly float Premultiply = premultiply;
    }

    // Wire order from valve/delta.lst usercmd_t.
    private static readonly FieldDef[] Fields =
    [
        new(0, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.LerpMsec)), FieldType.Short, 9),
        new(1, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.Msec)), FieldType.Byte, 8),
        new(2, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ViewAngle1)), FieldType.Angle, 16),
        new(3, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ViewAngle0)), FieldType.Angle, 16),
        new(4, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.Buttons)), FieldType.Short, 16),
        new(5, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ForwardMove)), FieldType.SignedFloat12, 12),
        new(6, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.LightLevel)), FieldType.Byte, 8),
        new(7, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.SideMove)), FieldType.SignedFloat12, 12),
        new(8, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.UpMove)), FieldType.SignedFloat12, 12),
        new(9, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.Impulse)), FieldType.Byte, 8),
        new(10, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ViewAngle2)), FieldType.Angle, 16),
        new(11, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ImpactIndex)), FieldType.Integer6, 6),
        new(12, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ImpactPos0)), FieldType.SignedFloat16x8, 16, 8f),
        new(13, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ImpactPos1)), FieldType.SignedFloat16x8, 16, 8f),
        new(14, (int)Marshal.OffsetOf<UserCmd>(nameof(UserCmd.ImpactPos2)), FieldType.SignedFloat16x8, 16, 8f)
    ];

    public static void WriteDelta(BitWriter writer, ReadOnlySpan<byte> from, ReadOnlySpan<byte> to)
    {
        var marked = 0u;
        for (var i = 0; i < FieldCount; i++)
        {
            if (!FieldEqual(from, to, Fields[i]))
                marked |= 1u << i;
        }

        if (marked == 0)
            return;

        var lastBit = 31 - BitOperations.LeadingZeroCount(marked);
        var byteCount = (lastBit >> 3) + 1;

        writer.WriteBits((uint)byteCount, 3);
        for (var b = 0; b < byteCount; b++)
            writer.WriteBits((marked >> (b * 8)) & 0xFF, 8);

        for (var i = 0; i < FieldCount; i++)
        {
            if ((marked & (1u << i)) == 0)
                continue;
            WriteField(writer, to, Fields[i]);
        }
    }

    private static bool FieldEqual(ReadOnlySpan<byte> from, ReadOnlySpan<byte> to, FieldDef field) =>
        field.Type switch
        {
            FieldType.Short => ReadUInt16(from, field.Offset) != ReadUInt16(to, field.Offset),
            FieldType.Byte => from[field.Offset] != to[field.Offset],
            FieldType.Angle => ReadSingle(from, field.Offset) != ReadSingle(to, field.Offset),
            FieldType.SignedFloat12 => ReadSingle(from, field.Offset) != ReadSingle(to, field.Offset),
            FieldType.Integer6 => ReadInt32(from, field.Offset) != ReadInt32(to, field.Offset),
            FieldType.SignedFloat16x8 => ReadSingle(from, field.Offset) != ReadSingle(to, field.Offset),
            _ => false
        };

    private static void WriteField(BitWriter writer, ReadOnlySpan<byte> data, FieldDef field)
    {
        switch (field.Type)
        {
            case FieldType.Short:
                writer.WriteBits(ReadUInt16(data, field.Offset), field.Bits);
                break;
            case FieldType.Byte:
                writer.WriteBits(data[field.Offset], field.Bits);
                break;
            case FieldType.Angle:
                WriteBitAngle(writer, ReadSingle(data, field.Offset), field.Bits);
                break;
            case FieldType.SignedFloat12:
                WriteSignedBits(writer, (int)ReadSingle(data, field.Offset), field.Bits);
                break;
            case FieldType.Integer6:
                writer.WriteBits((uint)ReadInt32(data, field.Offset), field.Bits);
                break;
            case FieldType.SignedFloat16x8:
                WriteSignedBits(writer, (int)(ReadSingle(data, field.Offset) * field.Premultiply), field.Bits);
                break;
        }
    }

    private static void WriteBitAngle(BitWriter writer, float angle, int bits)
    {
        var shift = 1 << bits;
        var mask = shift - 1;
        var normalized = angle % 360f;
        if (normalized < 0)
            normalized += 360f;
        var d = (int)(shift * normalized) / 360;
        writer.WriteBits((uint)(d & mask), bits);
    }

    private static void WriteSignedBits(BitWriter writer, int value, int bits)
    {
        var max = (1 << (bits - 1)) - 1;
        var min = -max;
        value = Math.Clamp(value, min, max);
        writer.WriteBit(value < 0);
        writer.WriteBits((uint)Math.Abs(value), bits - 1);
    }

    private static ushort ReadUInt16(ReadOnlySpan<byte> data, int offset) =>
        BitConverter.ToUInt16(data.Slice(offset, 2));

    private static int ReadInt32(ReadOnlySpan<byte> data, int offset) =>
        BitConverter.ToInt32(data.Slice(offset, 4));

    private static float ReadSingle(ReadOnlySpan<byte> data, int offset) =>
        BitConverter.ToSingle(data.Slice(offset, 4));
}
