namespace GoldSrcProbe.Protocol;

internal sealed class UserMessageInfo
{
    public string Name = string.Empty;
    public byte Size;
}

internal sealed class UserMessageRegistry
{
    private readonly Dictionary<byte, UserMessageInfo> _messages = [];

    public void Register(byte id, string name, byte size) =>
        _messages[id] = new UserMessageInfo { Name = name, Size = size };

    public bool TryGet(byte id, out UserMessageInfo info) => _messages.TryGetValue(id, out info!);

    public void Clear() => _messages.Clear();
}

internal static class ReAuthCheckerHandler
{
    /// <summary>
    /// ReAuthChecker uses custom usermessage (often #9). Real client responds via engine hooks.
    /// We ACK by sending clc_move + nop keepalive; some stages accept any traffic.
    /// </summary>
    public static bool IsReAuthStage(byte msgId, UserMessageInfo info) =>
        msgId == 9 || info.Name.Contains("ReAuth", StringComparison.OrdinalIgnoreCase);
}
