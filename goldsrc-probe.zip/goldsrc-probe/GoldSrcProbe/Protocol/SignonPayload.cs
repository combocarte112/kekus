using SharpCompress.Compressors;
using SharpCompress.Compressors.BZip2;

namespace GoldSrcProbe.Protocol;

internal static class SignonPayload
{
    /// <summary>ReHLDS may prefix fragmented signon blobs with a 4-byte BZ2 tag before bzip2 data.</summary>
    public static byte[] MaybeDecompress(byte[] payload)
    {
        if (payload.Length <= 4)
            return payload;

        if (payload[0] != (byte)'B' || payload[1] != (byte)'Z' || payload[2] != (byte)'2')
            return payload;

        try
        {
            using var input = new MemoryStream(payload, 4, payload.Length - 4);
            using var bzip = new BZip2Stream(input, CompressionMode.Decompress, false);
            using var output = new MemoryStream();
            bzip.CopyTo(output);
            return output.ToArray();
        }
        catch (Exception ex)
        {
            if (GoldSrcClient.DebugNet)
                Console.WriteLine($"  [net] BZ2 decompress failed: {ex.Message}");
            return payload;
        }
    }
}
