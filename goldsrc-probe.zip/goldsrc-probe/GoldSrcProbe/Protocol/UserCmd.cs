using System.Runtime.InteropServices;

namespace GoldSrcProbe.Protocol;

/// <summary>GoldSrc usercmd_t (common/usercmd.h), 4-byte aligned.</summary>
[StructLayout(LayoutKind.Sequential, Pack = 4)]
internal struct UserCmd
{
    public short LerpMsec;
    public byte Msec;
    public byte Pad0;
    public float ViewAngle0;
    public float ViewAngle1;
    public float ViewAngle2;
    public float ForwardMove;
    public float SideMove;
    public float UpMove;
    public byte LightLevel;
    public ushort Buttons;
    public byte Impulse;
    public byte WeaponSelect;
    public int ImpactIndex;
    public float ImpactPos0;
    public float ImpactPos1;
    public float ImpactPos2;

    public static UserCmd Idle(byte msec = 16) => new()
    {
        Msec = msec,
        LerpMsec = 0
    };

    public static ReadOnlySpan<byte> AsBytes(UserCmd cmd)
    {
        return MemoryMarshal.AsBytes(MemoryMarshal.CreateReadOnlySpan(ref cmd, 1));
    }
}
